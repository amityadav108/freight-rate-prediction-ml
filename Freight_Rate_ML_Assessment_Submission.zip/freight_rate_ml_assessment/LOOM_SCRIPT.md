# 2-3 Minute Loom Script

## 0:00-0:20 — Opening

“Hi, this is my solution to the Freight Rate Prediction Challenge. I’ll quickly cover the data findings, data-quality handling, model choice, validation strategy, and the main parts of the implementation.”

## 0:20-0:55 — Data exploration and quality

“The development set contains 48,000 labeled loads from January through October 2025, while the final validation set contains 12,000 loads from November and December.

The strongest signal is distance. I also found missing values in weight and market index, but the missingness is small: 300 weight values and 374 market-index values in training. I handled these with training-set medians and retained missingness indicators instead of dropping rows.

Another important finding is that the validation data contains eight cities not seen in the training categorical values. To make the model robust to that, I used latitude and longitude-derived geographic features rather than relying only on exact city names.”

## 0:55-1:30 — Validation and model choice

“I used time-based expanding-window validation instead of a random split because the real task is to learn from historical loads and predict future loads.

I evaluated August, September, and October as sequential holdouts. The average MAE was about 128.6, with an average R-squared of about 0.826.

For the model, I chose CatBoost because the data combines numeric variables with categorical route and equipment information. CatBoost handles categorical variables natively and captures nonlinear relationships and interactions without requiring a large manual one-hot encoding pipeline.”

## 1:30-2:15 — Code walkthrough

“The core implementation is in `src/features.py` and `src/train.py`.

`FeatureBuilder` centralizes preprocessing so the same transformations are applied consistently at training and inference. It creates calendar features, cyclical date features, a route key, geographic distance, distance-to-geographic-distance ratio, log transforms, weight-per-mile, quote-signal features, and missingness indicators.

`train.py` runs the temporal validation, trains the final CatBoost model on all 48,000 labeled rows, predicts all 12,000 validation loads, and generates the 31 December predictions.

Finally, I run the supplied `score.py`, which checks the exact 12,000 prediction IDs and validates the December file before generating the required chart.”

## 2:15-2:35 — Close

“The final submission therefore includes the reproducible code, dependencies, the 12,000-row `validation_predictions.csv`, the December predictions, the scorer-generated chart, and this report.

The main modeling takeaway is that distance and geographic route characteristics dominate the prediction, while equipment and market/quote signals provide important adjustments. The time-based validation gives a more realistic estimate of how the model should behave on the November-December prediction period.”
