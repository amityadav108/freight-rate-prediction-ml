# Freight Rate Prediction Challenge

A production-oriented solution for the Machine Learning Engineer assessment. The pipeline trains on `data/train_test.csv`, validates with expanding time-based holdouts, generates predictions for all 12,000 validation loads, and produces the required fixed December prediction chart.

## Results at a glance

- Development data: 48,000 labeled loads, January-October 2025
- Final prediction set: 12,000 loads, November-December 2025
- Primary validation design: expanding-window temporal validation
- Holdouts: August, September, and October 2025
- Mean temporal-CV MAE: ~131.0
- Mean temporal-CV R²: ~0.826
- Model: CatBoostRegressor with native categorical handling
- Final model complexity: 130 boosting iterations, depth 9
- Final scorer: validates all 12,000 IDs and all 31 December rows

## Repository structure

```text
.
├── data/
│   ├── train_test.csv
│   ├── validation.csv
│   ├── validation_predictions_template.csv
│   └── december_chart_inputs.csv
├── reports/
│   ├── temporal_cv_metrics.csv
│   └── Freight_Rate_ML_Assessment_Report.pdf
├── scorer_results/
│   └── candidate_december.png
├── src/
│   ├── __init__.py
│   ├── features.py
│   └── train.py
├── score.py
├── requirements.txt
├── validation_predictions.csv
├── LOOM_SCRIPT.md
└── README.md
```

## Setup

Python 3.10+ is recommended.

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

Install dependencies:

```bash
python -m pip install -r requirements.txt
```

## Reproduce the solution

From the repository root:

```bash
python src/train.py
```

This writes:

- `validation_predictions.csv`
- `data/december_chart_inputs.csv`
- `reports/temporal_cv_metrics.csv`

Then run the provided scorer:

```bash
python score.py   --predictions validation_predictions.csv   --december-predictions data/december_chart_inputs.csv
```

Expected output:

```text
Validated 12,000 final predictions.
Validated 31 fixed December predictions.
Created chart: scorer_results/candidate_december.png
Final validation metrics are calculated by Spotter after submission.
```

## Modeling approach

### 1. Data audit

The development data contains 48,000 labeled loads with:

- route endpoints and coordinates
- distance
- equipment type
- weight
- date
- market index
- quote signal
- posted rate target

The main data-quality issues were missing weight and market index values. Missingness was small and systematic enough to handle without dropping rows:

- train weight missing: 300 rows
- train market index missing: 374 rows
- validation weight missing: 165 rows
- validation market index missing: 249 rows

Training medians are used for imputation, and missingness indicators are retained as explicit features.

### 2. Feature engineering

The model receives:

- original numeric load features
- pickup, delivery, equipment, and route categorical features
- calendar features: month, day of week, day of year, ISO week
- cyclical calendar features using sine/cosine transforms
- geographic great-circle distance
- ratio of supplied distance to geographic distance
- distance and weight log transforms
- weight per mile
- quote signal per mile
- quote signal × market index
- missingness indicators

The geographic features are useful because the validation set introduces eight cities not seen in the development categorical values. Coordinates therefore provide a route representation that can generalize beyond exact city IDs.

### 3. Validation strategy

A random split would mix future and past observations and could give an overly optimistic estimate for a forecasting-style task. Instead, validation respects time.

Three expanding-window holdouts were used:

| Holdout | Training period | Validation period | MAE | RMSE | R² | MAPE |
|---|---|---|---:|---:|---:|---:|
| Aug 2025 | Jan-Jul | Aug | 144.78 | 619.69 | 0.823 | 7.46% |
| Sep 2025 | Jan-Aug | Sep | 118.54 | 618.31 | 0.835 | 5.51% |
| Oct 2025 | Jan-Sep | Oct | 129.57 | 647.37 | 0.821 | 7.73% |
| **Mean** | | | **130.97** | **628.46** | **0.826** | **6.94%** |

This setup is deliberately aligned with the real prediction direction: train on the past and predict later loads.

### 4. Model choice

CatBoostRegressor was selected because it handles mixed numeric and categorical data natively, is strong on nonlinear interactions, and can handle unseen categorical values at inference time.

The most influential final-model features were distance, log distance, geographic distance, quote signal per mile, and equipment. This is consistent with the economics of freight pricing: lane length is the dominant driver, while equipment and pricing signals adjust the rate.

### 5. December chart

The provided December inputs intentionally contain only the seven fields required by the scorer. For model-only fields not present in that file:

- city coordinates are reconstructed from the training data
- market index and quote signal use training medians

This keeps the December scenario controlled so that the chart primarily shows how the model responds to date/calendar effects while the route, distance, equipment, and weight remain fixed.

The required chart is generated by the provided `score.py` and is stored at:

`scorer_results/candidate_december.png`

## Output contract

`validation_predictions.csv` contains exactly:

```text
load_id,predicted_rate
```

It contains exactly 12,000 rows, preserves the validation `load_id` values, contains no duplicates, and all predictions are positive.

## Important design decisions

- No target leakage from validation data.
- No random train/test split for the primary estimate.
- No rows dropped because of small amounts of missing input data.
- Training-only statistics are used for imputation.
- Coordinates are used to improve generalization to unseen cities.
- The final output is checked by the supplied scorer before submission.

## Loom

See `LOOM_SCRIPT.md` for a concise 2-3 minute walkthrough covering the required topics.
