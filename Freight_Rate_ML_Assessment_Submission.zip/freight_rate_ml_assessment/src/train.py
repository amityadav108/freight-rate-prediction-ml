from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor, Pool
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from features import CAT_FEATURES, FeatureBuilder, add_december_model_inputs


def make_model(cat_indices: list[int], iterations: int = 130) -> CatBoostRegressor:
    return CatBoostRegressor(
        iterations=iterations,
        depth=9,
        learning_rate=0.05,
        loss_function="RMSE",
        random_seed=42,
        l2_leaf_reg=8,
        random_strength=1,
        cat_features=cat_indices,
        allow_writing_files=False,
        verbose=False,
    )


def run_temporal_cv(
    frame: pd.DataFrame,
    features: pd.DataFrame,
    target: pd.Series,
) -> pd.DataFrame:
    rows = []
    periods = ["2025-08", "2025-09", "2025-10"]

    for holdout in periods:
        train_mask = frame["date"].dt.to_period("M") < pd.Period(holdout)
        valid_mask = frame["date"].dt.to_period("M") == pd.Period(holdout)

        cat_indices = [features.columns.get_loc(c) for c in CAT_FEATURES]
        model = make_model(cat_indices, iterations=250)
        model.fit(
            Pool(features.loc[train_mask], target.loc[train_mask], cat_features=cat_indices),
            eval_set=Pool(
                features.loc[valid_mask],
                target.loc[valid_mask],
                cat_features=cat_indices,
            ),
            early_stopping_rounds=50,
            verbose=False,
        )

        prediction = model.predict(
            Pool(features.loc[valid_mask], cat_features=cat_indices)
        )
        actual = target.loc[valid_mask]

        rows.append(
            {
                "holdout": holdout,
                "train_rows": int(train_mask.sum()),
                "valid_rows": int(valid_mask.sum()),
                "best_iteration": int(model.get_best_iteration()),
                "MAE": mean_absolute_error(actual, prediction),
                "RMSE": mean_squared_error(actual, prediction) ** 0.5,
                "R2": r2_score(actual, prediction),
                "MAPE": float(np.mean(np.abs((actual - prediction) / actual))),
            }
        )

    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", default="data/train_test.csv")
    parser.add_argument("--validation", default="data/validation.csv")
    parser.add_argument("--december", default="data/december_chart_inputs.csv")
    parser.add_argument("--output", default="validation_predictions.csv")
    parser.add_argument("--cv-output", default="reports/temporal_cv_metrics.csv")
    args = parser.parse_args()

    train = pd.read_csv(args.train)
    validation = pd.read_csv(args.validation)
    december = pd.read_csv(args.december)

    train["date"] = pd.to_datetime(train["date"])
    validation["date"] = pd.to_datetime(validation["date"])
    december["date"] = pd.to_datetime(december["date"])

    target = train["posted_rate"].astype(float)

    builder = FeatureBuilder.fit(train)
    train_features = builder.transform(train)
    validation_features = builder.transform(validation)

    cv = run_temporal_cv(train, train_features, target)
    Path(args.cv_output).parent.mkdir(parents=True, exist_ok=True)
    cv.to_csv(args.cv_output, index=False)

    # The expanding-window CV selected ~130 trees as a conservative final
    # complexity level after the October holdout stabilized near 122 trees.
    cat_indices = [train_features.columns.get_loc(c) for c in CAT_FEATURES]
    final_model = make_model(cat_indices, iterations=130)
    final_model.fit(
        Pool(train_features, target, cat_features=cat_indices),
        verbose=False,
    )

    validation_prediction = np.maximum(
        final_model.predict(Pool(validation_features, cat_features=cat_indices)),
        1.0,
    )

    output = pd.DataFrame(
        {
            "load_id": validation["load_id"].astype(str),
            "predicted_rate": validation_prediction,
        }
    )
    output.to_csv(args.output, index=False)

    # The scorer's December input intentionally contains only seven columns.
    # Add deterministic city coordinates and training medians for model-only
    # fields, then write back only the required seven columns plus prediction.
    december_model_input = add_december_model_inputs(december, train)
    december_features = builder.transform(december_model_input)
    december_features = december_features.reindex(columns=train_features.columns)

    december_prediction = np.maximum(
        final_model.predict(Pool(december_features, cat_features=cat_indices)),
        1.0,
    )

    december_output = december.copy()
    december_output["predicted_rate"] = december_prediction
    december_output.to_csv(args.december, index=False)

    print("Temporal CV:")
    print(cv.to_string(index=False))
    print(f"\nSaved {len(output):,} validation predictions to {args.output}")
    print(f"Saved 31 December predictions to {args.december}")


if __name__ == "__main__":
    main()
