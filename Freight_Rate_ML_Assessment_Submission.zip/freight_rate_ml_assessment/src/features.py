from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


CAT_FEATURES = ["pickup", "delivery", "equipment", "route"]


@dataclass
class FeatureBuilder:
    weight_median: float
    market_median: float

    @classmethod
    def fit(cls, frame: pd.DataFrame) -> "FeatureBuilder":
        return cls(
            weight_median=float(frame["weight"].median()),
            market_median=float(frame["market_index"].median()),
        )

    def transform(self, frame: pd.DataFrame) -> pd.DataFrame:
        x = frame.copy()
        dt = pd.to_datetime(x["date"], errors="coerce")

        x["month"] = dt.dt.month.astype(int)
        x["dayofweek"] = dt.dt.dayofweek.astype(int)
        x["dayofyear"] = dt.dt.dayofyear.astype(int)
        x["weekofyear"] = dt.dt.isocalendar().week.astype(int)
        x["days_since_start"] = (dt - pd.Timestamp("2025-01-01")).dt.days.astype(int)

        x["month_sin"] = np.sin(2 * np.pi * x["month"] / 12)
        x["month_cos"] = np.cos(2 * np.pi * x["month"] / 12)
        x["dow_sin"] = np.sin(2 * np.pi * x["dayofweek"] / 7)
        x["dow_cos"] = np.cos(2 * np.pi * x["dayofweek"] / 7)

        x["route"] = x["pickup"].astype(str) + "__" + x["delivery"].astype(str)

        has_coordinates = all(
            c in x.columns
            for c in ["pickup_lat", "pickup_lon", "delivery_lat", "delivery_lon"]
        )
        if has_coordinates:
            lat1, lon1 = np.radians(x["pickup_lat"]), np.radians(x["pickup_lon"])
            lat2, lon2 = np.radians(x["delivery_lat"]), np.radians(x["delivery_lon"])
            a = (
                np.sin((lat2 - lat1) / 2) ** 2
                + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
            )
            x["geo_miles"] = 3958.8 * 2 * np.arcsin(np.sqrt(np.clip(a, 0, 1)))
            x["distance_per_geo"] = x["distance"] / (x["geo_miles"] + 1)
        else:
            # The December scorer input intentionally has no coordinates.
            x["geo_miles"] = x["distance"]
            x["distance_per_geo"] = 1.0

        x["weight_missing"] = x["weight"].isna().astype(int)
        x["market_missing"] = x["market_index"].isna().astype(int) if "market_index" in x else 1

        x["weight"] = x["weight"].fillna(self.weight_median)
        x["market_index"] = (
            x["market_index"].fillna(self.market_median)
            if "market_index" in x
            else self.market_median
        )

        x["weight_per_mile"] = x["weight"] / (x["distance"] + 1)
        x["distance_log"] = np.log1p(np.clip(x["distance"], 0, None))
        x["weight_log"] = np.log1p(np.clip(x["weight"], 0, None))
        x["quote_x_market"] = (
            x["quote_signal"] * x["market_index"]
            if "quote_signal" in x
            else 0.0
        )
        x["quote_per_mile"] = (
            x["quote_signal"] / (x["distance"] + 1)
            if "quote_signal" in x
            else 0.0
        )

        return x.drop(
            columns=[
                c
                for c in ["load_id", "date", "posted_rate", "predicted_rate"]
                if c in x.columns
            ]
        )


def add_december_model_inputs(
    december: pd.DataFrame,
    training: pd.DataFrame,
) -> pd.DataFrame:
    """Reconstruct non-scorer fields using training-only information.

    The provided December file contains only the seven fields required by the
    scorer. Coordinates are deterministic by city, while market/quote fields
    are set to training medians so the chart isolates date effects.
    """
    city_coords = pd.concat(
        [
            training[["pickup", "pickup_lat", "pickup_lon"]].rename(
                columns={"pickup": "city", "pickup_lat": "lat", "pickup_lon": "lon"}
            ),
            training[["delivery", "delivery_lat", "delivery_lon"]].rename(
                columns={"delivery": "city", "delivery_lat": "lat", "delivery_lon": "lon"}
            ),
        ]
    ).drop_duplicates("city").set_index("city")

    result = december.copy()
    result["pickup_lat"] = result["pickup"].map(city_coords["lat"])
    result["pickup_lon"] = result["pickup"].map(city_coords["lon"])
    result["delivery_lat"] = result["delivery"].map(city_coords["lat"])
    result["delivery_lon"] = result["delivery"].map(city_coords["lon"])
    result["market_index"] = float(training["market_index"].median())
    result["quote_signal"] = float(training["quote_signal"].median())
    return result
